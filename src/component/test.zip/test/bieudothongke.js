import { Bar } from "react-chartjs-2";
import {
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Divider,
  useTheme,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import axios from "axios";

const Bieudothongke = (props) => {
  const urlt = "http://10.0.17.28:8000/thietbituyensfilter/tuyen/T4/";
  const [chart, setChart] = useState([]);
  const theme = useTheme();

  let TBstable = [];
  let TBCTC = [];
  axios
    .get(urlt)
    .then(res => {
      console.log(res.data);
      for(const dataObj of res.data) {
        TBstable.push(dataObj.muc_on_dinh);
        TBCTC.push(dataObj.thiet_bi_cong_trinh_cha);
      }
    })
    .catch((err) => {
      console.log(err);
    });
  console.log(TBstable, TBCTC);

  const data = {
    datasets: [
      {
        backgroundColor: "rgba(124, 252, 0)",
        data: TBstable,
        label: ` Tinh trang thiet bi`,
      },
    ],
    labels: TBCTC,
  };

  const options = {
    animation: false,
    cornerRadius: 20,
    layout: { padding: 0 },
    legend: { display: false },
    maintainAspectRatio: false,
    responsive: true,
    events: ["mousemove", "click"],
    onHover: (event, chartElement) => {
      event.target.style.cursor = chartElement[0] ? "pointer" : "default";
    },

    scales: {
      xAxes: [
        {
          barThickness: 24,
          maxBarThickness: 30,
          barPercentage: 1.0,
          categoryPercentage: 1.0,
          ticks: {
            minRotation: 20,
            fontColor: theme.palette.text.secondary,
          },
          gridLines: {
            display: false,
            drawBorder: false,
          },
        },
      ],
      yAxes: [
        {
          ticks: {
            fontColor: theme.palette.text.secondary,
            beginAtZero: true,
            min: 0,
          },
          gridLines: {
            borderDash: [3],
            borderDashOffset: [2],
            color: theme.palette.divider,
            drawBorder: false,
            zeroLineBorderDash: [2],
            zeroLineBorderDashOffset: [2],
            zeroLineColor: theme.palette.divider,
          },
        },
      ],
    },
    tooltips: {
      backgroundColor: theme.palette.background.paper,
      bodyFontColor: theme.palette.text.secondary,
      borderColor: theme.palette.divider,
      borderWidth: 1,
      enabled: true,
      footerFontColor: theme.palette.text.secondary,
      intersect: false,
      mode: "index",
      titleFontColor: theme.palette.text.primary,
    },
  };

  return (
    <Card {...props}>
      <CardHeader title="THỐNG KÊ THIẾT BỊ" />
      <Divider />
      <CardContent>
        <Box
          style={{
            height: 300,
            position: "relative",
            overflowX: "auto",
          }}
        >
          <Bar data={data} options={options} />
        </Box>
        <Box>
          TBCTC
        </Box>
      </CardContent>
      <Divider />
    </Card>
  );
};

export default Bieudothongke;
